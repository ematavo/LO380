
pg_stop_backup();


